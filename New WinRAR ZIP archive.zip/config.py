import os

class Config:
    # Secret key untuk session & CSRF
    SECRET_KEY = 'musik-secret-key-uas'

    # Koneksi MySQL (phpMyAdmin / XAMPP)
    # Format: mysql+pymysql://username:password@host/database
    # SQLALCHEMY_DATABASE_URI = 'mysql+pymysql://root:@localhost/music_db'

    # Matikan warning
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    SQLALCHEMY_DATABASE_URI = 'mysql+pymysql://root:@localhost:3307/music_db'
    # SQLALCHEMY_DATABASE_URI = 'mysql+pymysql://admin:admin123@localhost/music_db'
