from flask import Flask, render_template, redirect, url_for, flash, request
from config import Config
from models import db, User, Song, Playlist, PlaylistSong
from form import LoginForm, SongForm, PlaylistForm
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.config.from_object(Config)

db.init_app(app)

login_manager = LoginManager(app)
login_manager.login_view = 'login'

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))


@app.route('/', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        password = form.password.data
        user = User.query.filter_by(username=form.username.data).first()
        password_hashed = user.password
        if user and check_password_hash(password_hashed, password):
            login_user(user)
            flash('Login berhasil', 'success')
            return redirect(url_for('dashboard'))
        flash('Login gagal', 'danger')
    return render_template('login.html', form=form)


@app.route('/dashboard')
@login_required
def dashboard():
    songs = Song.query.all()
    return render_template('dashboard.html', songs=songs)


@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))

#  CRUD Song Management Routes
@app.route('/songs')
@login_required
def songs():
    if current_user.role != 'admin':
        return redirect(url_for('dashboard'))
    return render_template('songs/index.html', songs=Song.query.all())


@app.route('/songs/add', methods=['GET', 'POST'])
@login_required
def add_song():
    if current_user.role != 'admin':
        return redirect(url_for('dashboard'))

    form = SongForm()
    if form.validate_on_submit():
        song = Song(
            title=form.title.data,
            artist=form.artist.data,
            genre=form.genre.data,
            duration=form.duration.data
        )
        db.session.add(song)
        db.session.commit()
        flash('Lagu berhasil ditambahkan', 'success')
        return redirect(url_for('songs'))
    return render_template('songs/form.html', form=form)

# Playlist Management Routes
@app.route('/playlists')
@login_required
def playlists():
    data = Playlist.query.filter_by(user_id=current_user.id).all()
    return render_template('playlists/index.html', playlists=data)


@app.route('/playlists/add', methods=['GET', 'POST'])
@login_required
def add_playlist():
    form = PlaylistForm()
    if form.validate_on_submit():
        playlist = Playlist(
            name=form.name.data,
            user_id=current_user.id
        )
        db.session.add(playlist)
        db.session.commit()
        flash('Playlist berhasil dibuat', 'success')
        return redirect(url_for('playlists'))
    return render_template('playlists/form.html', form=form)

if __name__ == '__main__':
    app.run(debug=True)


